import { users, newsletters, contacts, reviews, type User, type InsertUser, type Newsletter, type InsertNewsletter, type Contact, type InsertContact, type Review, type InsertReview } from "@shared/schema";

export interface IStorage {
  // Users
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Newsletter
  subscribeNewsletter(newsletter: InsertNewsletter): Promise<Newsletter>;
  getNewsletterByEmail(email: string): Promise<Newsletter | undefined>;
  
  // Contacts
  createContact(contact: InsertContact): Promise<Contact>;
  getContacts(): Promise<Contact[]>;
  
  // Reviews
  createReview(review: InsertReview): Promise<Review>;
  getReviews(): Promise<Review[]>;
  getVerifiedReviews(): Promise<Review[]>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private newsletters: Map<number, Newsletter>;
  private contacts: Map<number, Contact>;
  private reviews: Map<number, Review>;
  private currentUserId: number;
  private currentNewsletterId: number;
  private currentContactId: number;
  private currentReviewId: number;

  constructor() {
    this.users = new Map();
    this.newsletters = new Map();
    this.contacts = new Map();
    this.reviews = new Map();
    this.currentUserId = 1;
    this.currentNewsletterId = 1;
    this.currentContactId = 1;
    this.currentReviewId = 1;
    
    // Add some sample reviews
    this.seedData();
  }

  private seedData() {
    const sampleReviews = [
      {
        name: "Sarah M.",
        email: "sarah@example.com",
        rating: 5,
        title: "Life-changing skincare routine!",
        content: "This kit has completely transformed my sensitive skin routine. No more redness or irritation!",
        skinType: "Sensitive",
        verified: true,
        createdAt: new Date('2024-06-10'),
      },
      {
        name: "Jessica Chen",
        email: "jessica@example.com",
        rating: 5,
        title: "Finally found my holy grail!",
        content: "Finally found a routine that doesn't irritate my sensitive skin. The results are incredible!",
        skinType: "Sensitive",
        verified: true,
        createdAt: new Date('2024-06-12'),
      },
      {
        name: "Michael Rodriguez",
        email: "michael@example.com",
        rating: 5,
        title: "Dermatologist recommended",
        content: "My dermatologist recommended this after nothing else worked. So grateful I found ELOWRA!",
        skinType: "Acne-prone",
        verified: true,
        createdAt: new Date('2024-06-14'),
      },
      {
        name: "Emma Thompson",
        email: "emma@example.com",
        rating: 5,
        title: "Convenient subscription service",
        content: "The subscription service is so convenient, and my skin has never looked better!",
        skinType: "Dry",
        verified: true,
        createdAt: new Date('2024-06-16'),
      },
      {
        name: "Rachel K.",
        email: "rachel@example.com",
        rating: 5,
        title: "Amazing results in 3 months",
        content: "I've been using ELOWRA for 3 months now and my skin has never looked better. The redness is completely gone!",
        skinType: "Sensitive",
        verified: true,
        createdAt: new Date('2024-06-18'),
      },
      {
        name: "David L.",
        email: "david@example.com",
        rating: 5,
        title: "No more breakouts!",
        content: "Finally found a routine that doesn't break me out. The subscription service is so convenient too!",
        skinType: "Acne-prone",
        verified: true,
        createdAt: new Date('2024-06-20'),
      }
    ];

    sampleReviews.forEach(review => {
      const id = this.currentReviewId++;
      const reviewWithId: Review = { ...review, id };
      this.reviews.set(id, reviewWithId);
    });
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async subscribeNewsletter(insertNewsletter: InsertNewsletter): Promise<Newsletter> {
    const existing = await this.getNewsletterByEmail(insertNewsletter.email);
    if (existing) {
      return existing;
    }
    
    const id = this.currentNewsletterId++;
    const newsletter: Newsletter = { 
      ...insertNewsletter, 
      id, 
      subscribed: true,
      createdAt: new Date()
    };
    this.newsletters.set(id, newsletter);
    return newsletter;
  }

  async getNewsletterByEmail(email: string): Promise<Newsletter | undefined> {
    return Array.from(this.newsletters.values()).find(
      (newsletter) => newsletter.email === email,
    );
  }

  async createContact(insertContact: InsertContact): Promise<Contact> {
    const id = this.currentContactId++;
    const contact: Contact = { 
      ...insertContact, 
      id, 
      createdAt: new Date()
    };
    this.contacts.set(id, contact);
    return contact;
  }

  async getContacts(): Promise<Contact[]> {
    return Array.from(this.contacts.values());
  }

  async createReview(insertReview: InsertReview): Promise<Review> {
    const id = this.currentReviewId++;
    const review: Review = { 
      ...insertReview, 
      id, 
      verified: false,
      createdAt: new Date(),
      skinType: insertReview.skinType || null
    };
    this.reviews.set(id, review);
    return review;
  }

  async getReviews(): Promise<Review[]> {
    return Array.from(this.reviews.values()).sort(
      (a, b) => b.createdAt!.getTime() - a.createdAt!.getTime()
    );
  }

  async getVerifiedReviews(): Promise<Review[]> {
    return Array.from(this.reviews.values())
      .filter(review => review.verified)
      .sort((a, b) => b.createdAt!.getTime() - a.createdAt!.getTime());
  }
}

export const storage = new MemStorage();
