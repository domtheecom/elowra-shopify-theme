# ELOWRA Skincare E-commerce Application

## Overview

ELOWRA is a full-stack e-commerce application for a skincare brand specializing in sensitive skin products. The application features a modern React frontend with a Node.js/Express backend, utilizing PostgreSQL for data persistence and Drizzle ORM for database operations.

## System Architecture

The application follows a monorepo structure with clear separation between client, server, and shared components:

- **Frontend**: React with TypeScript, using Vite for bundling
- **Backend**: Express.js server with TypeScript
- **Database**: PostgreSQL with Drizzle ORM
- **UI Framework**: Tailwind CSS with shadcn/ui components
- **State Management**: TanStack Query for server state
- **Routing**: Wouter for client-side routing

## Key Components

### Frontend Architecture
- **React Components**: Modular component structure with shadcn/ui for consistent design
- **Pages**: Home, Product Detail, About, Ingredients, Reviews, Blog, FAQ, Contact
- **State Management**: TanStack Query for API calls and caching
- **Styling**: Tailwind CSS with custom sage color palette
- **Forms**: React Hook Form with Zod validation

### Backend Architecture
- **Express Server**: RESTful API with middleware for logging and error handling
- **Storage Layer**: Abstract storage interface with in-memory implementation for development
- **Database Schema**: Four main entities - users, newsletters, contacts, reviews
- **API Endpoints**: Newsletter subscription, contact form, review management

### Database Design
The application defines four main database tables:
1. **Users**: Authentication (username, password)
2. **Newsletters**: Email subscriptions with opt-in/opt-out capability
3. **Contacts**: Customer inquiries and support requests
4. **Reviews**: Product reviews with ratings and verification status

### UI Components
- **ProductCard**: Displays product information with pricing and features
- **TestimonialCard**: Shows customer reviews with ratings
- **NewsletterSignup**: Email subscription form with validation
- **Header/Footer**: Navigation and brand information

## Data Flow

1. **Client Requests**: React components make API calls using TanStack Query
2. **Server Processing**: Express routes handle requests, validate data with Zod schemas
3. **Database Operations**: Drizzle ORM manages database interactions
4. **Response**: JSON responses sent back to client with success/error states
5. **UI Updates**: React components update based on response data

## External Dependencies

### Frontend Dependencies
- **UI Library**: Radix UI primitives with shadcn/ui
- **Animation**: Framer Motion for smooth transitions
- **Icons**: Lucide React icon library
- **Date Handling**: date-fns for date manipulation
- **Form Handling**: React Hook Form with Hookform Resolvers

### Backend Dependencies
- **Database**: @neondatabase/serverless for PostgreSQL connection
- **ORM**: Drizzle ORM with Drizzle Kit for migrations
- **Validation**: Zod for schema validation
- **Session Management**: connect-pg-simple for PostgreSQL sessions

### Development Tools
- **Build Tool**: Vite with TypeScript support
- **Code Quality**: ESBuild for server bundling
- **Development**: tsx for TypeScript execution
- **Replit Integration**: Custom Vite plugins for Replit environment

## Deployment Strategy

The application is configured for deployment on Replit with the following setup:

- **Development**: `npm run dev` starts both client and server in development mode
- **Build Process**: `npm run build` creates production builds for both frontend and backend
- **Production**: `npm run start` runs the production server
- **Database**: Configured to use PostgreSQL 16 with automatic provisioning
- **Port Configuration**: Server runs on port 5000 with external port 80 mapping

The build process uses Vite for the frontend (outputting to `dist/public`) and ESBuild for the backend (outputting to `dist`), ensuring optimized production bundles.

## Changelog

```
Changelog:
- June 24, 2025. Initial setup
- June 24, 2025. Created complete Shopify conversion guide with component migration, product setup, and development scripts
```

## User Preferences

```
Preferred communication style: Simple, everyday language.
Interested in: Shopify integration and maintaining edit capabilities for the ELOWRA website.
```