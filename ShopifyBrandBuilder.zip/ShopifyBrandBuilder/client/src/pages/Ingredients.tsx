import { motion } from "framer-motion";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ingredients } from "@/data/ingredients";

export default function Ingredients() {
  return (
    <div className="pt-16">
      {/* Hero Section */}
      <section className="py-20 bg-sage-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <motion.h1 
              className="text-4xl font-bold text-gray-900 mb-4"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
            >
              Pure, Powerful Ingredients
            </motion.h1>
            <motion.p 
              className="text-xl text-gray-600 max-w-2xl mx-auto"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
            >
              Every ingredient is carefully selected and clinically tested for sensitive skin compatibility.
            </motion.p>
          </div>
        </div>
      </section>

      {/* Ingredients Grid */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {ingredients.map((ingredient, index) => (
              <motion.div
                key={ingredient.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
              >
                <Card className="h-full hover:shadow-xl transition-shadow duration-300">
                  <CardContent className="p-8">
                    <img 
                      src={ingredient.image} 
                      alt={ingredient.name} 
                      className="w-full h-48 object-cover rounded-lg mb-6"
                    />
                    <h3 className="text-xl font-bold text-gray-900 mb-3">
                      {ingredient.name}
                    </h3>
                    <p className="text-gray-600 mb-4">{ingredient.benefits}</p>
                    <div className="space-y-2 text-sm text-gray-500">
                      <div className="flex justify-between">
                        <span>Function:</span>
                        <span className="font-medium">{ingredient.function}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Source:</span>
                        <span className="font-medium">{ingredient.source}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Best for:</span>
                        <span className="font-medium">{ingredient.skinType}</span>
                      </div>
                    </div>
                    <div className="mt-4">
                      <Badge variant="secondary" className="bg-sage-100 text-sage-600">
                        {ingredient.function}
                      </Badge>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Ingredient Safety */}
      <section className="py-20 bg-sage-50">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold text-gray-900 mb-8">Our Commitment to Safety</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
            <div>
              <div className="text-4xl font-bold text-sage-500 mb-2">100%</div>
              <div className="text-gray-600">Dermatologist Approved</div>
            </div>
            <div>
              <div className="text-4xl font-bold text-sage-500 mb-2">12</div>
              <div className="text-gray-600">Months Clinical Testing</div>
            </div>
            <div>
              <div className="text-4xl font-bold text-sage-500 mb-2">0</div>
              <div className="text-gray-600">Harmful Additives</div>
            </div>
          </div>
          <p className="text-lg text-gray-600 mb-8">
            All ingredients are clinically tested, dermatologist-approved, and sourced sustainably. 
            We exclude over 1,500 potentially harmful ingredients from our formulations.
          </p>
          <div className="flex flex-wrap justify-center gap-4 mb-8">
            <Badge className="bg-sage-100 text-sage-600 px-4 py-2">Fragrance-Free</Badge>
            <Badge className="bg-sage-100 text-sage-600 px-4 py-2">Hypoallergenic</Badge>
            <Badge className="bg-sage-100 text-sage-600 px-4 py-2">Non-Comedogenic</Badge>
            <Badge className="bg-sage-100 text-sage-600 px-4 py-2">pH Balanced</Badge>
            <Badge className="bg-sage-100 text-sage-600 px-4 py-2">Paraben-Free</Badge>
            <Badge className="bg-sage-100 text-sage-600 px-4 py-2">Sulfate-Free</Badge>
          </div>
          <Button 
            size="lg"
            className="bg-sage-500 hover:bg-sage-600 text-white px-8 py-4"
          >
            View Full Ingredient List
          </Button>
        </div>
      </section>

      {/* How We Source */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              How We Source Our Ingredients
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              We work directly with ethical suppliers to ensure the highest quality and sustainability standards.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <Card>
              <CardContent className="p-6 text-center">
                <div className="w-16 h-16 bg-sage-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <span className="text-sage-500 text-2xl">🔬</span>
                </div>
                <h3 className="font-semibold text-gray-900 mb-2">Lab Tested</h3>
                <p className="text-sm text-gray-600">
                  Every batch is tested for purity, potency, and safety
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6 text-center">
                <div className="w-16 h-16 bg-sage-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <span className="text-sage-500 text-2xl">🌱</span>
                </div>
                <h3 className="font-semibold text-gray-900 mb-2">Sustainably Sourced</h3>
                <p className="text-sm text-gray-600">
                  Ethically harvested with minimal environmental impact
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6 text-center">
                <div className="w-16 h-16 bg-sage-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <span className="text-sage-500 text-2xl">🤝</span>
                </div>
                <h3 className="font-semibold text-gray-900 mb-2">Fair Trade</h3>
                <p className="text-sm text-gray-600">
                  Supporting communities and fair wages for farmers
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6 text-center">
                <div className="w-16 h-16 bg-sage-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <span className="text-sage-500 text-2xl">📋</span>
                </div>
                <h3 className="font-semibold text-gray-900 mb-2">Certified</h3>
                <p className="text-sm text-gray-600">
                  Meeting the highest industry standards and certifications
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>
    </div>
  );
}
