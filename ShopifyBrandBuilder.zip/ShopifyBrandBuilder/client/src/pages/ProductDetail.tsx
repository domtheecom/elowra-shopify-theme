import { useState } from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Star, Truck, RotateCcw, Shield, Plus, Minus } from "lucide-react";
import { ritualKit, individualProducts } from "@/data/products";
import { useToast } from "@/hooks/use-toast";

export default function ProductDetail() {
  const [selectedImage, setSelectedImage] = useState(0);
  const [quantity, setQuantity] = useState(1);
  const [purchaseType, setPurchaseType] = useState("subscription");
  const { toast } = useToast();

  const productImages = [
    "https://images.unsplash.com/photo-1620916566398-39f1143ab7be?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=600",
    "https://images.unsplash.com/photo-1515377905703-c4788e51af15?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=600",
    "https://images.unsplash.com/photo-1556228578-8c89e6adf883?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=600",
    "https://images.unsplash.com/photo-1611930022073-b7a4ba5fcccd?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=600"
  ];

  const subscriptionPrice = Math.round(ritualKit.price * 0.85);
  const currentPrice = purchaseType === "subscription" ? subscriptionPrice : ritualKit.price;

  const handleAddToCart = () => {
    toast({
      title: "Added to cart!",
      description: `${ritualKit.name} has been added to your cart.`,
    });
  };

  const handleAddToWishlist = () => {
    toast({
      title: "Added to wishlist!",
      description: `${ritualKit.name} has been saved to your wishlist.`,
    });
  };

  return (
    <div className="pt-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16">
          {/* Product Images */}
          <div>
            <div className="mb-6">
              <img 
                src={productImages[selectedImage]} 
                alt="The Complete Ritual Kit" 
                className="w-full h-96 object-cover rounded-2xl shadow-lg"
              />
            </div>
            <div className="grid grid-cols-4 gap-4">
              {productImages.map((image, index) => (
                <img
                  key={index}
                  src={image}
                  alt={`Product view ${index + 1}`}
                  className={`w-full h-20 object-cover rounded-lg cursor-pointer transition-opacity ${
                    selectedImage === index ? 'opacity-100 ring-2 ring-sage-500' : 'opacity-75 hover:opacity-100'
                  }`}
                  onClick={() => setSelectedImage(index)}
                />
              ))}
            </div>
          </div>

          {/* Product Details */}
          <div>
            <h1 className="text-4xl font-bold text-gray-900 mb-4">
              {ritualKit.name}
            </h1>
            
            <div className="flex items-center mb-6">
              <div className="flex text-yellow-400 mr-2">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="h-5 w-5 fill-current" />
                ))}
              </div>
              <span className="text-gray-600">(127 reviews)</span>
            </div>

            {/* Pricing */}
            <div className="mb-8">
              <div className="flex items-baseline space-x-4 mb-4">
                <span className="text-3xl font-bold text-gray-900">
                  ${currentPrice}
                </span>
                {ritualKit.originalPrice && (
                  <span className="text-xl text-gray-500 line-through">
                    ${ritualKit.originalPrice}
                  </span>
                )}
                <Badge className="bg-sage-100 text-sage-600">
                  Save {Math.round(((ritualKit.originalPrice! - currentPrice) / ritualKit.originalPrice!) * 100)}%
                </Badge>
              </div>
              <p className="text-gray-600">
                {purchaseType === "subscription" 
                  ? "Subscribe and save 15% on every order"
                  : "Or subscribe and save 15% on every order"
                }
              </p>
            </div>

            {/* Purchase Options */}
            <div className="space-y-4 mb-8">
              <Card className={`cursor-pointer transition-all ${
                purchaseType === "subscription" 
                  ? "border-2 border-sage-500 bg-sage-50" 
                  : "border hover:border-sage-300"
              }`}>
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="flex items-center">
                        <input 
                          type="radio" 
                          name="purchase-type" 
                          value="subscription"
                          checked={purchaseType === "subscription"}
                          onChange={(e) => setPurchaseType(e.target.value)}
                          className="text-sage-500 mr-3" 
                        />
                        <span className="font-semibold text-gray-900">Subscribe & Save</span>
                        <Badge className="bg-sage-500 text-white ml-2">Best Value</Badge>
                      </div>
                      <p className="text-sm text-gray-600 ml-6">
                        ${subscriptionPrice} every 2 months • Free shipping • Cancel anytime
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              <Card className={`cursor-pointer transition-all ${
                purchaseType === "one-time" 
                  ? "border-2 border-sage-500 bg-sage-50" 
                  : "border hover:border-sage-300"
              }`}>
                <CardContent className="p-4">
                  <div className="flex items-center">
                    <input 
                      type="radio" 
                      name="purchase-type" 
                      value="one-time"
                      checked={purchaseType === "one-time"}
                      onChange={(e) => setPurchaseType(e.target.value)}
                      className="text-sage-500 mr-3" 
                    />
                    <span className="font-semibold text-gray-900">One-time purchase</span>
                  </div>
                  <p className="text-sm text-gray-600 ml-6">
                    ${ritualKit.price} • Free shipping on orders over $75
                  </p>
                </CardContent>
              </Card>
            </div>

            {/* Quantity */}
            <div className="flex items-center space-x-4 mb-8">
              <span className="font-semibold text-gray-900">Quantity:</span>
              <div className="flex items-center border rounded-lg">
                <Button 
                  variant="ghost" 
                  size="sm"
                  onClick={() => setQuantity(Math.max(1, quantity - 1))}
                  className="px-3 py-2"
                >
                  <Minus className="h-4 w-4" />
                </Button>
                <span className="px-4 py-2 border-x">{quantity}</span>
                <Button 
                  variant="ghost" 
                  size="sm"
                  onClick={() => setQuantity(quantity + 1)}
                  className="px-3 py-2"
                >
                  <Plus className="h-4 w-4" />
                </Button>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="space-y-4 mb-8">
              <Button 
                onClick={handleAddToCart}
                className="w-full bg-sage-500 hover:bg-sage-600 text-white py-4 text-lg"
                size="lg"
              >
                Add to Cart
              </Button>
              <Button 
                onClick={handleAddToWishlist}
                variant="outline"
                className="w-full border-2 border-sage-500 text-sage-500 hover:bg-sage-50 py-4"
                size="lg"
              >
                Add to Wishlist
              </Button>
            </div>

            {/* Trust Badges */}
            <div className="grid grid-cols-3 gap-4 text-center text-sm text-gray-600">
              <div className="flex flex-col items-center">
                <Truck className="h-6 w-6 text-sage-500 mb-2" />
                <p>Free Shipping</p>
              </div>
              <div className="flex flex-col items-center">
                <RotateCcw className="h-6 w-6 text-sage-500 mb-2" />
                <p>30-Day Returns</p>
              </div>
              <div className="flex flex-col items-center">
                <Shield className="h-6 w-6 text-sage-500 mb-2" />
                <p>Secure Checkout</p>
              </div>
            </div>
          </div>
        </div>

        {/* Product Information Tabs */}
        <div className="mt-20">
          <Tabs defaultValue="description" className="w-full">
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="description">Description</TabsTrigger>
              <TabsTrigger value="ingredients">Ingredients</TabsTrigger>
              <TabsTrigger value="reviews">Reviews</TabsTrigger>
              <TabsTrigger value="faq">FAQ</TabsTrigger>
            </TabsList>
            
            <TabsContent value="description" className="py-8">
              <div className="prose max-w-none">
                <h3 className="text-2xl font-bold text-gray-900 mb-4">
                  The Complete 3-Step Ritual
                </h3>
                <p className="text-gray-600 mb-6">
                  Our carefully curated skincare system is designed specifically for sensitive, dry, and allergy-prone skin. 
                  Each product works synergistically to cleanse, hydrate, and protect your skin barrier.
                </p>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                  <div>
                    <h4 className="font-semibold text-gray-900 mb-3">How to Use</h4>
                    <ol className="space-y-2 text-gray-600">
                      <li><strong>Morning & Evening:</strong> Apply CloudClean™ to damp skin, massage gently, rinse with lukewarm water</li>
                      <li><strong>Follow with:</strong> 2-3 drops of VeilDew™ serum, press into clean skin</li>
                      <li><strong>Evening only:</strong> Apply MoonSilk™ moisturizer as final step</li>
                    </ol>
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-900 mb-3">Key Benefits</h4>
                    <ul className="space-y-2 text-gray-600">
                      <li>• Reduces redness and irritation</li>
                      <li>• Strengthens skin barrier function</li>
                      <li>• Provides 24-hour hydration</li>
                      <li>• Clinically proven gentle formula</li>
                      <li>• Suitable for all skin types</li>
                    </ul>
                  </div>
                </div>
              </div>
            </TabsContent>
            
            <TabsContent value="ingredients" className="py-8">
              <h3 className="text-2xl font-bold text-gray-900 mb-6">Full Ingredient List</h3>
              <div className="space-y-6">
                {individualProducts.map((product) => (
                  <Card key={product.id}>
                    <CardContent className="p-6">
                      <h4 className="font-semibold text-gray-900 mb-3">{product.name}</h4>
                      <p className="text-sm text-gray-600 mb-3">
                        Key ingredients include hyaluronic acid, ceramides, niacinamide, and peptide complex
                      </p>
                      <div className="flex flex-wrap gap-2">
                        {product.features.map((feature, index) => (
                          <Badge key={index} variant="secondary" className="bg-sage-100 text-sage-600">
                            {feature}
                          </Badge>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>
            
            <TabsContent value="reviews" className="py-8">
              <div className="flex items-center justify-between mb-8">
                <h3 className="text-2xl font-bold text-gray-900">Customer Reviews</h3>
                <Button className="bg-sage-500 hover:bg-sage-600 text-white">
                  Write a Review
                </Button>
              </div>
              {/* Reviews would be loaded from API */}
              <div className="text-center py-8">
                <p className="text-gray-600">Reviews will be loaded from the reviews API</p>
              </div>
            </TabsContent>
            
            <TabsContent value="faq" className="py-8">
              <h3 className="text-2xl font-bold text-gray-900 mb-6">Frequently Asked Questions</h3>
              <div className="space-y-4">
                <Card>
                  <CardContent className="p-6">
                    <h4 className="font-semibold text-gray-900 mb-2">
                      How long does one kit last?
                    </h4>
                    <p className="text-gray-600">
                      Each kit is designed to last approximately 2 months with regular daily use as directed.
                    </p>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="p-6">
                    <h4 className="font-semibold text-gray-900 mb-2">
                      Is it suitable for acne-prone skin?
                    </h4>
                    <p className="text-gray-600">
                      Yes, our formula is non-comedogenic and gentle enough for acne-prone sensitive skin.
                    </p>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
}
