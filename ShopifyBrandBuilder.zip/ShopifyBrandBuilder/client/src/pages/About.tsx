import { motion } from "framer-motion";
import { Card, CardContent } from "@/components/ui/card";

export default function About() {
  return (
    <div className="pt-16">
      {/* Founder Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6 }}
            >
              <h1 className="text-4xl font-bold text-gray-900 mb-6">Meet Our Founder</h1>
              <h2 className="text-2xl font-semibold text-sage-500 mb-4">Mira Lenox</h2>
              <p className="text-lg text-gray-600 mb-6">
                "After years of struggling with sensitive skin and trying countless products that promised relief, 
                I decided to create the solution I couldn't find anywhere else."
              </p>
              <p className="text-gray-600 mb-8">
                As a biochemist with a passion for natural skincare, Mira spent over 3 years researching and developing 
                the perfect formulations for sensitive skin. ELOWRA was born from her personal journey and scientific expertise.
              </p>
              <div className="grid grid-cols-2 gap-8 text-center">
                <div>
                  <div className="text-3xl font-bold text-sage-500 mb-2">3+</div>
                  <div className="text-gray-600">Years of Research</div>
                </div>
                <div>
                  <div className="text-3xl font-bold text-sage-500 mb-2">1000+</div>
                  <div className="text-gray-600">Formula Tests</div>
                </div>
              </div>
            </motion.div>
            
            <motion.div 
              className="relative"
              initial={{ opacity: 0, x: 30 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6 }}
            >
              <img 
                src="https://images.unsplash.com/photo-1559839734-2b71ea197ec2?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=600" 
                alt="Mira Lenox, ELOWRA Founder" 
                className="w-full h-auto rounded-2xl shadow-xl"
              />
            </motion.div>
          </div>
        </div>
      </section>

      {/* Mission Statement */}
      <section className="py-20 bg-sage-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h2 className="text-3xl font-bold text-gray-900 mb-8">Our Mission</h2>
            <div className="max-w-4xl mx-auto">
              <p className="text-xl text-gray-600 leading-relaxed">
                To provide gentle, effective skincare solutions for sensitive skin types, backed by science 
                and created with the highest standards of safety and sustainability. We believe everyone 
                deserves to feel confident and comfortable in their own skin.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Our Story */}
      <section className="py-20 bg-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-gray-900 mb-12 text-center">The ELOWRA Story</h2>
          
          <div className="space-y-12">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
            >
              <Card>
                <CardContent className="p-8">
                  <div className="flex items-center mb-4">
                    <div className="w-8 h-8 bg-sage-500 text-white rounded-full flex items-center justify-center font-bold mr-4">
                      1
                    </div>
                    <h3 className="text-xl font-semibold text-gray-900">The Problem</h3>
                  </div>
                  <p className="text-gray-600 ml-12">
                    Mira's journey began with her own struggle with sensitive, reactive skin. After years of trying 
                    countless products that either didn't work or caused more irritation, she realized there was a 
                    gap in the market for truly gentle, effective skincare.
                  </p>
                </CardContent>
              </Card>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
            >
              <Card>
                <CardContent className="p-8">
                  <div className="flex items-center mb-4">
                    <div className="w-8 h-8 bg-sage-500 text-white rounded-full flex items-center justify-center font-bold mr-4">
                      2
                    </div>
                    <h3 className="text-xl font-semibold text-gray-900">The Research</h3>
                  </div>
                  <p className="text-gray-600 ml-12">
                    Drawing on her background in biochemistry, Mira dove deep into research on skin barrier function, 
                    ingredient compatibility, and the specific needs of sensitive skin. This led to over 1000 formula 
                    tests and 3 years of rigorous development.
                  </p>
                </CardContent>
              </Card>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.4 }}
            >
              <Card>
                <CardContent className="p-8">
                  <div className="flex items-center mb-4">
                    <div className="w-8 h-8 bg-sage-500 text-white rounded-full flex items-center justify-center font-bold mr-4">
                      3
                    </div>
                    <h3 className="text-xl font-semibold text-gray-900">The Solution</h3>
                  </div>
                  <p className="text-gray-600 ml-12">
                    ELOWRA was born from this dedication to creating products that are both powerfully effective and 
                    gentle enough for the most sensitive skin. Every product is dermatologist-reviewed, clinically 
                    tested, and formulated with the highest safety standards.
                  </p>
                </CardContent>
              </Card>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Values */}
      <section className="py-20 bg-sage-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-gray-900 mb-12 text-center">Our Values</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <Card>
              <CardContent className="p-8 text-center">
                <div className="w-16 h-16 bg-sage-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <span className="text-sage-500 text-2xl">🧪</span>
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-4">Science-Backed</h3>
                <p className="text-gray-600">
                  Every ingredient is chosen based on scientific research and clinical testing to ensure maximum efficacy and safety.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-8 text-center">
                <div className="w-16 h-16 bg-sage-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <span className="text-sage-500 text-2xl">💚</span>
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-4">Ethical</h3>
                <p className="text-gray-600">
                  We're committed to cruelty-free, vegan formulations and sustainable practices throughout our supply chain.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-8 text-center">
                <div className="w-16 h-16 bg-sage-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <span className="text-sage-500 text-2xl">🤝</span>
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-4">Transparent</h3>
                <p className="text-gray-600">
                  We believe in complete transparency about our ingredients, processes, and the science behind our formulations.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>
    </div>
  );
}
