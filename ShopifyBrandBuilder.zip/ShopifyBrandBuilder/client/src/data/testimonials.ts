import { Testimonial } from "@/lib/types";

export const testimonials: Testimonial[] = [
  {
    id: "1",
    name: "Jessica Chen",
    content: "Finally found a routine that doesn't irritate my sensitive skin. The results are incredible!",
    rating: 5,
    image: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&h=100",
    skinType: "Sensitive",
    verified: true
  },
  {
    id: "2",
    name: "Michael Rodriguez",
    content: "My dermatologist recommended this after nothing else worked. So grateful I found ELOWRA!",
    rating: 5,
    image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&h=100",
    skinType: "Acne-prone",
    verified: true
  },
  {
    id: "3",
    name: "Emma Thompson",
    content: "The subscription service is so convenient, and my skin has never looked better!",
    rating: 5,
    image: "https://images.unsplash.com/photo-1506863530036-1efeddceb993?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&h=100",
    skinType: "Dry",
    verified: true
  }
];
