import { BlogPost } from "@/lib/types";

export const blogPosts: BlogPost[] = [
  {
    id: "gentle-skincare-routine",
    title: "Building a Gentle Skincare Routine for Sensitive Skin",
    excerpt: "Learn the essential steps to create a routine that soothes and protects sensitive skin without causing irritation.",
    content: `
      <h2>Understanding Sensitive Skin</h2>
      <p>Sensitive skin requires special care and attention. It's important to choose products that are formulated specifically for your skin type...</p>
      
      <h2>The Essential Steps</h2>
      <ol>
        <li><strong>Gentle Cleansing:</strong> Start with a mild, pH-balanced cleanser that won't strip your skin's natural oils.</li>
        <li><strong>Hydrating Serum:</strong> Apply a lightweight serum with ingredients like hyaluronic acid to lock in moisture.</li>
        <li><strong>Protective Moisturizer:</strong> Finish with a barrier-repairing moisturizer to seal in hydration and protect your skin.</li>
      </ol>
      
      <h2>Key Ingredients to Look For</h2>
      <p>When choosing products for sensitive skin, look for ingredients like ceramides, niacinamide, and allantoin...</p>
    `,
    image: "https://images.unsplash.com/photo-1515377905703-c4788e51af15?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400",
    category: "Skincare Tips",
    publishedAt: "2024-06-15",
    readTime: 5
  },
  {
    id: "ceramides-guide",
    title: "Ceramides: The Key to Healthy Skin Barrier",
    excerpt: "Discover why ceramides are essential for maintaining healthy skin and how they can transform your skincare routine.",
    content: `
      <h2>What Are Ceramides?</h2>
      <p>Ceramides are naturally occurring lipids that make up about 50% of your skin's barrier. They play a crucial role in maintaining skin hydration and protection...</p>
      
      <h2>Benefits of Ceramides</h2>
      <ul>
        <li>Strengthen the skin barrier</li>
        <li>Prevent moisture loss</li>
        <li>Reduce inflammation</li>
        <li>Improve skin texture</li>
      </ul>
      
      <h2>How to Incorporate Ceramides</h2>
      <p>Look for products that contain different types of ceramides, such as Ceramide NP, AP, and EOP...</p>
    `,
    image: "https://images.unsplash.com/photo-1583947215259-38e31be8751f?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400",
    category: "Ingredient Spotlight",
    publishedAt: "2024-06-12",
    readTime: 4
  },
  {
    id: "natural-vs-synthetic",
    title: "Natural vs Synthetic: What Really Matters in Skincare",
    excerpt: "Understanding the science behind ingredient sourcing and why efficacy matters more than origin.",
    content: `
      <h2>Breaking Down the Myths</h2>
      <p>There's a common misconception that natural ingredients are always better than synthetic ones. The truth is more nuanced...</p>
      
      <h2>The Science Behind Efficacy</h2>
      <p>What matters most is not whether an ingredient is natural or synthetic, but how it's formulated and whether it's effective for your skin type...</p>
      
      <h2>Making Informed Choices</h2>
      <p>When choosing skincare products, focus on ingredients that have been clinically tested and proven effective...</p>
    `,
    image: "https://images.unsplash.com/photo-1556228578-8c89e6adf883?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400",
    category: "Brand Updates",
    publishedAt: "2024-06-10",
    readTime: 6
  }
];
