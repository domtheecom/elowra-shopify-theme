import { FAQItem } from "@/lib/types";

export const faqItems: FAQItem[] = [
  {
    id: "1",
    question: "How long does it take to see results?",
    answer: "Most customers start noticing improvements in skin texture and hydration within 1-2 weeks. For more significant changes like reduced redness and improved barrier function, allow 4-6 weeks of consistent use. Remember, everyone's skin is different, and results may vary.",
    category: "General"
  },
  {
    id: "2",
    question: "Is ELOWRA suitable for all skin types?",
    answer: "Yes! While ELOWRA was specifically formulated for sensitive, dry, and allergy-prone skin, our gentle yet effective formulations are suitable for all skin types, including oily and combination skin. The products are non-comedogenic and won't clog pores.",
    category: "General"
  },
  {
    id: "3",
    question: "How do I use the 3-step ritual?",
    answer: "Morning & Evening: Apply CloudClean™ to damp skin, massage gently, rinse with lukewarm water. Follow with 2-3 drops of VeilDew™ serum to clean, slightly damp skin. For evening routine, finish with MoonSilk™ moisturizer. Always follow with SPF during the day.",
    category: "General"
  },
  {
    id: "4",
    question: "What's the difference between one-time purchase and subscription?",
    answer: "With our subscription service, you save 15% on every order, get free shipping, and receive your products automatically every 2 months (perfect timing for when you'll run out). You can modify, pause, or cancel your subscription anytime with no penalties. One-time purchases are great for trying our products, but the subscription offers the best value for ongoing use.",
    category: "Subscription Management"
  },
  {
    id: "5",
    question: "Are your products cruelty-free and vegan?",
    answer: "Absolutely! All ELOWRA products are 100% cruelty-free and vegan. We never test on animals, nor do we sell in countries that require animal testing. Our products contain no animal-derived ingredients and are certified by leading cruelty-free organizations.",
    category: "Product Safety"
  },
  {
    id: "6",
    question: "What if I'm not satisfied with my purchase?",
    answer: "We offer a 30-day money-back guarantee. If you're not completely satisfied with your ELOWRA products, you can return them (even if used) within 30 days of purchase for a full refund. Just contact our customer service team, and we'll make it right. Your satisfaction is our priority.",
    category: "Shipping & Returns"
  },
  {
    id: "7",
    question: "How long does one kit last?",
    answer: "Each kit is designed to last approximately 2 months with regular daily use as directed.",
    category: "General"
  },
  {
    id: "8",
    question: "Is it suitable for acne-prone skin?",
    answer: "Yes, our formula is non-comedogenic and gentle enough for acne-prone sensitive skin.",
    category: "Product Safety"
  }
];
