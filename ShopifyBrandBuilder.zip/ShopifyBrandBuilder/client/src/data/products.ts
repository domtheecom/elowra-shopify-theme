import { Product } from "@/lib/types";

export const products: Product[] = [
  {
    id: "cloudclean",
    name: "CloudClean™",
    description: "Gentle cleansing foam that removes impurities without stripping natural oils.",
    price: 28,
    image: "https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400",
    features: [
      "Hypoallergenic formula",
      "pH balanced",
      "Fragrance-free"
    ],
    step: 1
  },
  {
    id: "veildew",
    name: "VeilDew™",
    description: "Lightweight hydrating serum that locks in moisture for 24-hour comfort.",
    price: 45,
    image: "https://images.unsplash.com/photo-1620916566398-39f1143ab7be?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400",
    features: [
      "Hyaluronic acid complex",
      "Non-comedogenic",
      "Fast absorbing"
    ],
    step: 2
  },
  {
    id: "moonsilk",
    name: "MoonSilk™",
    description: "Rich night moisturizer that repairs and rejuvenates while you sleep.",
    price: 52,
    image: "https://images.unsplash.com/photo-1556228578-8c89e6adf883?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400",
    features: [
      "Peptide complex",
      "Barrier repair",
      "Anti-inflammatory"
    ],
    step: 3
  },
  {
    id: "ritual-kit",
    name: "The Ritual Kit",
    description: "Complete 3-step skincare system designed for sensitive, dry, and allergy-prone skin.",
    price: 89,
    originalPrice: 120,
    image: "https://images.unsplash.com/photo-1620916566398-39f1143ab7be?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=600",
    features: [
      "Complete 3-step system",
      "2-month supply",
      "Dermatologist reviewed",
      "Clinically tested",
      "Allergen-safe"
    ]
  }
];

export const ritualKit = products.find(p => p.id === "ritual-kit")!;
export const individualProducts = products.filter(p => p.id !== "ritual-kit");
