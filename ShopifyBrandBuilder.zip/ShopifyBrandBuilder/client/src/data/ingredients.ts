import { Ingredient } from "@/lib/types";

export const ingredients: Ingredient[] = [
  {
    id: "hyaluronic-acid",
    name: "Hyaluronic Acid",
    function: "Hydration",
    benefits: "Holds up to 1000x its weight in water, providing intense hydration without clogging pores.",
    source: "Fermented",
    skinType: "All Types",
    image: "https://images.unsplash.com/photo-1583947215259-38e31be8751f?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300"
  },
  {
    id: "ceramides",
    name: "Ceramides",
    function: "Barrier Repair",
    benefits: "Essential lipids that restore and maintain the skin's protective barrier function.",
    source: "Plant-Derived",
    skinType: "Dry, Sensitive",
    image: "https://images.unsplash.com/photo-1612815154858-60aa4c59eaa6?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300"
  },
  {
    id: "niacinamide",
    name: "Niacinamide",
    function: "Anti-Inflammatory",
    benefits: "Vitamin B3 that reduces inflammation, minimizes pores, and regulates oil production.",
    source: "Synthetic",
    skinType: "Oily, Sensitive",
    image: "https://images.unsplash.com/photo-1576671081837-49000212a370?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300"
  },
  {
    id: "peptide-complex",
    name: "Peptide Complex",
    function: "Anti-Aging",
    benefits: "Amino acid chains that stimulate collagen production and improve skin texture.",
    source: "Bioengineered",
    skinType: "Mature, All Types",
    image: "https://images.unsplash.com/photo-1559181567-c3190ca9959b?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300"
  },
  {
    id: "squalane",
    name: "Squalane",
    function: "Moisturizing",
    benefits: "Lightweight oil that mimics skin's natural sebum, providing deep moisturization.",
    source: "Olive-Derived",
    skinType: "Dry, Dehydrated",
    image: "https://images.unsplash.com/photo-1474418397713-7ede21d49118?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300"
  },
  {
    id: "allantoin",
    name: "Allantoin",
    function: "Soothing",
    benefits: "Soothing compound that reduces irritation and promotes skin healing.",
    source: "Plant Extract",
    skinType: "Sensitive, Irritated",
    image: "https://images.unsplash.com/photo-1584464491033-06628f3a6b7b?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300"
  }
];
