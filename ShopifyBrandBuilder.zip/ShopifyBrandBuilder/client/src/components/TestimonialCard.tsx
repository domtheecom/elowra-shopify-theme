import { Testimonial } from "@/lib/types";
import { Card, CardContent } from "@/components/ui/card";
import { Star } from "lucide-react";

interface TestimonialCardProps {
  testimonial: Testimonial;
}

export default function TestimonialCard({ testimonial }: TestimonialCardProps) {
  return (
    <Card className="bg-white rounded-2xl shadow-lg">
      <CardContent className="p-8">
        <div className="flex text-yellow-400 mb-4">
          {[...Array(5)].map((_, i) => (
            <Star 
              key={i} 
              className={`h-5 w-5 ${i < testimonial.rating ? 'fill-current' : ''}`} 
            />
          ))}
        </div>
        
        <p className="text-gray-600 mb-6">{testimonial.content}</p>
        
        <div className="flex items-center">
          <img 
            src={testimonial.image} 
            alt={testimonial.name} 
            className="w-12 h-12 rounded-full mr-4"
          />
          <div>
            <p className="font-semibold text-gray-900">{testimonial.name}</p>
            <div className="flex items-center space-x-2">
              {testimonial.verified && (
                <div className="w-2 h-2 bg-green-500 rounded-full"></div>
              )}
              <p className="text-gray-500 text-sm">
                {testimonial.verified ? "Verified Buyer" : "Customer"}
                {testimonial.skinType && ` • ${testimonial.skinType}`}
              </p>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
