import { Product } from "@/lib/types";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

interface ProductCardProps {
  product: Product;
  showStep?: boolean;
}

export default function ProductCard({ product, showStep = false }: ProductCardProps) {
  const discountPercentage = product.originalPrice 
    ? Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100)
    : 0;

  return (
    <Card className="bg-white rounded-2xl shadow-lg hover:shadow-xl transition-shadow duration-300">
      <CardContent className="p-8">
        <div className="text-center mb-6">
          {showStep && product.step && (
            <div className="w-12 h-12 bg-sage-200 rounded-full flex items-center justify-center mx-auto mb-4">
              <span className="text-sage-600 font-bold text-xl">{product.step}</span>
            </div>
          )}
          <img 
            src={product.image} 
            alt={product.name} 
            className="w-full h-64 object-cover rounded-lg mb-4"
          />
        </div>
        
        <div className="flex items-center justify-between mb-2">
          <h3 className="text-2xl font-bold text-gray-900">{product.name}</h3>
          {discountPercentage > 0 && (
            <Badge className="bg-sage-100 text-sage-600">
              Save {discountPercentage}%
            </Badge>
          )}
        </div>
        
        <p className="text-gray-600 mb-4">{product.description}</p>
        
        <div className="flex items-center mb-4">
          <span className="text-2xl font-bold text-gray-900">${product.price}</span>
          {product.originalPrice && (
            <span className="text-lg text-gray-500 line-through ml-2">
              ${product.originalPrice}
            </span>
          )}
        </div>
        
        <ul className="text-sm text-gray-500 space-y-1">
          {product.features.map((feature, index) => (
            <li key={index}>• {feature}</li>
          ))}
        </ul>
      </CardContent>
    </Card>
  );
}
