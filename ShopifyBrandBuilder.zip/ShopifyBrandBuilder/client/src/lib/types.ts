export interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  originalPrice?: number;
  image: string;
  features: string[];
  step?: number;
}

export interface Testimonial {
  id: string;
  name: string;
  content: string;
  rating: number;
  image: string;
  skinType?: string;
  verified: boolean;
}

export interface Ingredient {
  id: string;
  name: string;
  function: string;
  benefits: string;
  source: string;
  skinType: string;
  image: string;
}

export interface BlogPost {
  id: string;
  title: string;
  excerpt: string;
  content: string;
  image: string;
  category: string;
  publishedAt: string;
  readTime: number;
}

export interface FAQItem {
  id: string;
  question: string;
  answer: string;
  category: string;
}

export interface CartItem extends Product {
  quantity: number;
  subscriptionType: 'one-time' | 'subscription';
}
