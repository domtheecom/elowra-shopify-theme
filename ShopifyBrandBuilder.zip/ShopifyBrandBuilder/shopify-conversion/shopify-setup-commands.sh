#!/bin/bash

# ELOWRA Shopify Setup Script
# Run this script to set up your Shopify development environment

echo "🌿 ELOWRA Shopify Setup"
echo "======================="

# Step 1: Install Shopify CLI
echo "📦 Installing Shopify CLI..."
npm install -g @shopify/cli @shopify/theme

# Step 2: Create Hydrogen app
echo "⚛️  Creating Hydrogen app..."
npm create @shopify/hydrogen@latest elowra-shopify -- --template hello-world

# Step 3: Navigate to project
cd elowra-shopify

# Step 4: Install additional dependencies for ELOWRA
echo "📋 Installing ELOWRA dependencies..."
npm install framer-motion clsx tailwind-merge class-variance-authority
npm install -D tailwindcss autoprefixer postcss

# Step 5: Set up Tailwind CSS
echo "🎨 Setting up Tailwind CSS..."
npx tailwindcss init -p

# Step 6: Create basic folder structure
echo "📁 Creating project structure..."
mkdir -p app/components/ui
mkdir -p app/data
mkdir -p app/lib

# Step 7: Copy ELOWRA styles (you'll need to do this manually)
echo "✨ Setup complete!"
echo ""
echo "Next steps:"
echo "1. Run 'shopify app configure' to connect your development store"
echo "2. Copy your ELOWRA components to app/components/"
echo "3. Set up your product catalog in Shopify admin"
echo "4. Run 'shopify hydrogen dev' to start development server"
echo ""
echo "📖 See component-migration-guide.md for detailed migration steps"