# Component Migration Guide

## Converting React Components to Shopify Hydrogen

This guide shows how to adapt your existing ELOWRA components for Shopify Hydrogen.

## 1. Product Components

### Before (Current React)
```tsx
// client/src/components/ProductCard.tsx
export default function ProductCard({ product, showStep = false }: ProductCardProps) {
  return (
    <Card className="bg-white rounded-2xl shadow-lg">
      <CardContent className="p-8">
        <img src={product.image} alt={product.name} />
        <h3>{product.name}</h3>
        <p>${product.price}</p>
      </CardContent>
    </Card>
  );
}
```

### After (Shopify Hydrogen)
```tsx
// app/components/ProductCard.tsx
import {Image, Money} from '@shopify/hydrogen';

export default function ProductCard({product, showStep = false}) {
  return (
    <div className="bg-white rounded-2xl shadow-lg">
      <div className="p-8">
        <Image data={product.featuredImage} alt={product.title} />
        <h3>{product.title}</h3>
        <Money data={product.priceRange.minVariantPrice} />
      </div>
    </div>
  );
}
```

## 2. Cart Integration

### Before (Custom Cart)
```tsx
const [cartCount, setCartCount] = useState(2);
```

### After (Hydrogen Cart)
```tsx
import {useCart} from '@shopify/hydrogen';

export default function Header() {
  const {totalQuantity} = useCart();
  
  return (
    <Button>
      <ShoppingBag />
      {totalQuantity > 0 && <span>{totalQuantity}</span>}
    </Button>
  );
}
```

## 3. Product Data Fetching

### Before (Static Data)
```tsx
import { products } from "@/data/products";
```

### After (GraphQL Query)
```tsx
// app/routes/products._index.tsx
import {useLoaderData} from '@remix-run/react';
import {LoaderFunctionArgs} from '@shopify/remix-oxygen';

export async function loader({context}: LoaderFunctionArgs) {
  const {storefront} = context;
  
  const products = await storefront.query(PRODUCTS_QUERY);
  return {products: products.products.nodes};
}

const PRODUCTS_QUERY = `#graphql
  query Products {
    products(first: 20) {
      nodes {
        id
        title
        handle
        priceRange {
          minVariantPrice {
            amount
            currencyCode
          }
        }
        featuredImage {
          url
          altText
        }
      }
    }
  }
`;
```

## 4. Newsletter Signup

### Before (Custom API)
```tsx
const subscribeMutation = useMutation({
  mutationFn: async (email: string) => {
    return apiRequest("POST", "/api/newsletter", { email });
  }
});
```

### After (Shopify Customer API)
```tsx
import {useFetcher} from '@remix-run/react';

export default function NewsletterSignup() {
  const fetcher = useFetcher();
  
  return (
    <fetcher.Form method="post" action="/newsletter">
      <input name="email" type="email" required />
      <button type="submit">Subscribe</button>
    </fetcher.Form>
  );
}

// app/routes/newsletter.tsx
export async function action({request, context}: ActionFunctionArgs) {
  const {storefront} = context;
  const formData = await request.formData();
  const email = formData.get('email');
  
  // Create customer or add to mailing list
  await storefront.mutate(CUSTOMER_CREATE_MUTATION, {
    variables: {input: {email, acceptsMarketing: true}}
  });
}
```

## 5. Reviews Integration

### Before (Custom Reviews)
```tsx
const { data: reviews = [] } = useQuery({
  queryKey: ["/api/reviews?verified=true"],
});
```

### After (Shopify Metafields or App)
```tsx
// Option 1: Using Shopify Reviews App
import {ProductReviews} from '@shopify/hydrogen-react';

export default function ProductReviews({productId}) {
  return <ProductReviews productId={productId} />;
}

// Option 2: Custom metafields
const PRODUCT_WITH_REVIEWS_QUERY = `#graphql
  query Product($handle: String!) {
    product(handle: $handle) {
      id
      title
      reviews: metafield(namespace: "custom", key: "reviews") {
        value
      }
    }
  }
`;
```

## File Structure Comparison

### Current Structure
```
client/src/
├── components/
├── pages/
├── data/
└── lib/
```

### Hydrogen Structure
```
app/
├── components/
├── routes/
├── lib/
└── styles/
```

## Key Differences

1. **Data Fetching**: Use Shopify's GraphQL API instead of static data
2. **Routing**: Remix file-based routing instead of Wouter
3. **Cart**: Hydrogen's built-in cart instead of custom state
4. **Payments**: Shopify's secure checkout instead of custom forms
5. **Products**: Shopify product model instead of custom types

## Migration Priority

1. **Core Components** (Header, Footer, ProductCard)
2. **Product Pages** (Detail, Listing)
3. **Cart Functionality**
4. **Checkout Integration**
5. **Content Pages** (About, Blog, FAQ)
6. **Forms** (Contact, Reviews, Newsletter)

## Testing Strategy

1. Set up development store with sample products
2. Migrate components one by one
3. Test each component thoroughly
4. Verify cart and checkout flow
5. Test on mobile devices
6. Performance testing
7. SEO verification