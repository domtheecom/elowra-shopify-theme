# Complete Step-by-Step Guide: ELOWRA Website on Shopify

## Phase 1: Initial Shopify Setup (30 minutes)

### Step 1: Create Shopify Account
1. Go to shopify.com
2. Click "Start free trial"
3. Enter store name: "elowra" or "elowra-skincare"
4. Complete account setup
5. Skip theme selection for now

### Step 2: Install Dawn Theme
1. Go to **Online Store > Themes**
2. Click **Visit Theme Store**
3. Search for "Dawn" (it's free)
4. Click **Add to theme library**
5. Click **Actions > Publish** to make it live

### Step 3: Basic Store Settings
1. Go to **Settings > General**
2. Store name: "ELOWRA"
3. Store address: Enter your business address
4. Currency: USD
5. Time zone: Your timezone
6. Click **Save**

## Phase 2: Product Setup (45 minutes)

### Step 4: Create Product Categories
1. Go to **Products > Collections**
2. Click **Create collection**

**Collection 1: The Ritual Kit**
- Title: "The Ritual Kit"
- Collection type: Manual
- Save

**Collection 2: Individual Products**
- Title: "Individual Products" 
- Collection type: Manual
- Save

**Collection 3: Sensitive Skin**
- Title: "Sensitive Skin Care"
- Collection type: Manual
- Save

### Step 5: Add Products

**Product 1: CloudClean™ Gentle Cleanser**
1. Go to **Products > All products**
2. Click **Add product**
3. **Title**: CloudClean™ Gentle Cleanser
4. **Description**: 
```
Gentle cleansing foam that removes impurities without stripping natural oils. Perfect for sensitive, dry, and allergy-prone skin.

✓ Hypoallergenic formula
✓ pH balanced  
✓ Fragrance-free
✓ Step 1 of the 3-step ritual
```
5. **Images**: Upload product image (use: https://images.unsplash.com/photo-1620916566398-39f1143ab7be?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&h=1000)
6. **Pricing**: $28.00
7. **SKU**: ELOWRA-CC-001
8. **Inventory**: Track quantity (set to 100)
9. **Shipping**: Requires shipping, 4 oz weight
10. **SEO**: 
    - Title: "CloudClean™ Gentle Cleanser - Sensitive Skin Face Wash | ELOWRA"
    - Description: "Gentle cleansing foam for sensitive skin. Hypoallergenic, pH balanced, fragrance-free. Step 1 of ELOWRA's 3-step skincare ritual."
11. **Collections**: Add to "Individual Products" and "Sensitive Skin"
12. **Product type**: Cleanser
13. **Vendor**: ELOWRA
14. **Tags**: sensitive-skin, step-1, cleanser, gentle
15. Click **Save**

**Product 2: VeilDew™ Hydrating Serum**
1. Click **Add product**
2. **Title**: VeilDew™ Hydrating Serum
3. **Description**:
```
Lightweight hydrating serum that locks in moisture for 24-hour comfort. Advanced hyaluronic acid complex penetrates deep for lasting hydration.

✓ Hyaluronic acid complex
✓ Non-comedogenic
✓ Fast absorbing
✓ Step 2 of the 3-step ritual
```
4. **Images**: Upload (use: https://images.unsplash.com/photo-1608248543803-ba4f8c70ae0b?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&h=1000)
5. **Pricing**: $45.00
6. **SKU**: ELOWRA-VD-001
7. **Inventory**: 100 units
8. **Collections**: "Individual Products", "Sensitive Skin"
9. **Tags**: sensitive-skin, step-2, serum, hydrating
10. Click **Save**

**Product 3: MoonSilk™ Night Moisturizer**
1. Click **Add product**
2. **Title**: MoonSilk™ Night Moisturizer
3. **Description**:
```
Rich night moisturizer that repairs and rejuvenates while you sleep. Advanced peptide complex supports skin barrier function.

✓ Peptide complex
✓ Barrier repair
✓ Anti-inflammatory
✓ Step 3 of the 3-step ritual
```
4. **Images**: Upload (use: https://images.unsplash.com/photo-1616394584738-fc6e612e71b9?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&h=1000)
5. **Pricing**: $52.00
6. **SKU**: ELOWRA-MS-001
7. **Inventory**: 100 units
8. **Collections**: "Individual Products", "Sensitive Skin"
9. **Tags**: sensitive-skin, step-3, moisturizer, night-care
10. Click **Save**

**Product 4: The Ritual Kit**
1. Click **Add product**
2. **Title**: The Ritual Kit - Complete 3-Step System
3. **Description**:
```
Complete 3-step skincare system for sensitive, dry, and allergy-prone skin. Save $36 when you buy the complete kit.

Includes:
• CloudClean™ Gentle Cleanser (120ml)
• VeilDew™ Hydrating Serum (30ml) 
• MoonSilk™ Night Moisturizer (50ml)

✓ 2-month supply
✓ Free shipping included
✓ Dermatologist recommended routine
```
4. **Images**: Upload bundle image
5. **Pricing**: 
   - Price: $89.00
   - Compare at price: $125.00
6. **SKU**: ELOWRA-KIT-001
7. **Inventory**: 50 units
8. **Collections**: "The Ritual Kit", "Sensitive Skin"
9. **Tags**: bundle, ritual-kit, bestseller, complete-system
10. Click **Save**

## Phase 3: Theme Customization (60 minutes)

### Step 6: Add Custom CSS
1. Go to **Online Store > Themes**
2. Click **Actions > Edit code** on Dawn theme
3. Find **Assets > base.css** 
4. Scroll to bottom of file
5. Copy and paste the complete CSS from `complete-homepage-css.css`
6. Click **Save**

### Step 7: Create Homepage Sections

**Hero Section:**
1. Go to **Online Store > Themes > Customize**
2. Click **Add section** > **Custom Liquid**
3. Add this HTML:
```html
<div class="elowra-homepage">
  <section class="elowra-hero">
    <div class="elowra-hero-container">
      <div class="elowra-hero-content">
        <h1 class="elowra-hero-title">
          Naturally Radiant.<br>
          <span class="sage-text">Powerfully Gentle.</span>
        </h1>
        <p class="elowra-hero-subtitle">
          The 3-step skincare ritual for sensitive, dry, and allergy-prone skin.
        </p>
        <div class="elowra-hero-buttons">
          <a href="/products/the-ritual-kit-complete-3-step-system" class="elowra-btn-primary">
            Subscribe Now
          </a>
          <a href="/products/the-ritual-kit-complete-3-step-system" class="elowra-btn-secondary">
            See What's Inside
          </a>
        </div>
      </div>
      <div class="elowra-hero-image">
        <img src="https://images.unsplash.com/photo-1620916566398-39f1143ab7be?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&h=1000" 
             alt="ELOWRA Ritual Kit">
      </div>
    </div>
  </section>
</div>
```
4. Click **Save**

**Trust Badges Section:**
1. Click **Add section** > **Custom Liquid**
2. Add this HTML:
```html
<section class="elowra-trust-section">
  <div class="elowra-trust-container">
    <h2 class="elowra-trust-title">Why Choose ELOWRA?</h2>
    <div class="elowra-trust-grid">
      <div class="elowra-trust-item">
        <div class="elowra-trust-icon">
          <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/>
            <circle cx="9" cy="7" r="4"/>
            <path d="M22 21v-2a4 4 0 0 0-3-3.87"/>
            <path d="M16 3.13a4 4 0 0 1 0 7.75"/>
          </svg>
        </div>
        <h3>Dermatologist Reviewed</h3>
        <p>Clinically validated by skin experts</p>
      </div>
      <div class="elowra-trust-item">
        <div class="elowra-trust-icon">
          <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M9 11a3 3 0 1 1 6 0 3 3 0 0 1-6 0Z"/>
            <path d="M17.5 17.5 22 22"/>
          </svg>
        </div>
        <h3>Clinically Tested</h3>
        <p>12 months of rigorous testing</p>
      </div>
      <div class="elowra-trust-item">
        <div class="elowra-trust-icon">
          <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10"/>
          </svg>
        </div>
        <h3>Allergen-Safe</h3>
        <p>Safe for sensitive skin types</p>
      </div>
      <div class="elowra-trust-item">
        <div class="elowra-trust-icon">
          <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M11 20A7 7 0 0 1 9.8 6.1C15.5 5 17 4.48 19 2c1 2 2 4.18 2 8 0 5.5-4.78 10-10 10Z"/>
            <path d="M2 21c0-3 1.85-5.36 5.08-6C9.5 14.52 12 13 13 12"/>
          </svg>
        </div>
        <h3>Vegan + Cruelty-Free</h3>
        <p>Ethical and sustainable</p>
      </div>
      <div class="elowra-trust-item">
        <div class="elowra-trust-icon">
          <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M7 19H4.815a1.83 1.83 0 0 1-1.57-.881 1.785 1.785 0 0 1-.004-1.784L7.196 9.5"/>
            <path d="M11 19h8.203a1.83 1.83 0 0 0 1.556-.89 1.784 1.784 0 0 0 0-1.775L14.204 4.5a1.91 1.91 0 0 0-1.49-.757 1.909 1.909 0 0 0-1.49.757L2.344 16.334a1.784 1.784 0 0 0-.013 1.775A1.83 1.83 0 0 0 3.896 19H7.1"/>
            <path d="M13.5 11.5 16 9"/>
            <path d="M16 16v-4l-3 3"/>
          </svg>
        </div>
        <h3>Sustainable Packaging</h3>
        <p>Environmentally conscious</p>
      </div>
    </div>
  </div>
</section>
```
3. Click **Save**

**Product Section:**
1. Click **Add section** > **Featured collection**
2. Select "Individual Products" collection
3. Show 3 products
4. Enable "Show vendor"
5. Click **Save**

**Testimonials Section:**
1. Click **Add section** > **Custom Liquid**
2. Add testimonials HTML (detailed in next steps)

### Step 8: Set Up Navigation
1. Go to **Online Store > Navigation**
2. Click **Main menu**
3. Remove default items
4. Add these menu items:
   - **Home** → / 
   - **The Ritual Kit** → /collections/the-ritual-kit
   - **Individual Products** → /collections/individual-products
   - **About** → /pages/about
   - **Ingredients** → /pages/ingredients
   - **Reviews** → /pages/reviews  
   - **Blog** → /blogs/skincare-tips
   - **FAQ** → /pages/faq
   - **Contact** → /pages/contact
5. Click **Save menu**

## Phase 4: Page Creation (45 minutes)

### Step 9: Create About Page
1. Go to **Online Store > Pages**
2. Click **Add page**
3. **Title**: About
4. **Content**:
```html
<div class="elowra-about-section">
  <div class="elowra-about-container">
    <div class="elowra-about-content">
      <h2>Meet Our Founder</h2>
      <h3>Mira Lenox</h3>
      <p>"After years of struggling with sensitive skin and trying countless products that promised relief, I decided to create the solution I couldn't find anywhere else."</p>
      <p>As a biochemist with a passion for natural skincare, Mira spent over 3 years researching and developing the perfect formulations for sensitive skin.</p>
    </div>
    <div class="elowra-about-image">
      <img src="https://images.unsplash.com/photo-1559839734-2b71ea197ec2?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=600" alt="Mira Lenox, ELOWRA Founder">
    </div>
  </div>
</div>
```
5. **SEO**: Title "About ELOWRA - Our Story | Premium Skincare for Sensitive Skin"
6. Click **Save**

### Step 10: Create Additional Pages
Create these pages using the same process:

**FAQ Page:**
- Title: FAQ
- Content: List of common questions about products and shipping

**Contact Page:**
- Title: Contact
- Content: Contact form and business information

**Ingredients Page:**
- Title: Ingredients  
- Content: Detailed ingredient information

**Reviews Page:**
- Title: Reviews
- Content: Customer testimonials and review form

## Phase 5: Final Setup (30 minutes)

### Step 11: Configure Shipping
1. Go to **Settings > Shipping and delivery**
2. Click **Manage rates** for your region
3. Add shipping rate:
   - Name: "Standard Shipping"
   - Price: $5.99
   - Free shipping: Orders over $75
4. Click **Save**

### Step 12: Payment Setup
1. Go to **Settings > Payments**
2. Set up Shopify Payments or your preferred payment provider
3. Enable relevant payment methods

### Step 13: Newsletter Setup
1. Go to **Settings > Customer accounts**
2. Enable "Customers can create accounts"
3. Set up email marketing in **Marketing > Campaigns**

### Step 14: Launch Checklist
- [ ] Test all product pages
- [ ] Test checkout process
- [ ] Verify mobile responsiveness
- [ ] Check all navigation links
- [ ] Test contact forms
- [ ] Review SEO settings
- [ ] Set up Google Analytics
- [ ] Configure domain (if ready)

## Phase 6: Going Live

### Step 15: Remove Password Protection
1. Go to **Online Store > Preferences**
2. Uncheck "Restrict access with password"
3. Click **Save**

### Step 16: Custom Domain (Optional)
1. Purchase domain (elowra.com)
2. Go to **Settings > Domains**
3. Click **Connect existing domain**
4. Follow DNS setup instructions

## Time Estimate: 3-4 Hours Total
- Phase 1: 30 minutes
- Phase 2: 45 minutes  
- Phase 3: 60 minutes
- Phase 4: 45 minutes
- Phase 5: 30 minutes
- Phase 6: 15 minutes

Your ELOWRA website will be live and fully functional, matching the exact design and functionality of your current site.