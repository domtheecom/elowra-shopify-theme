# Shopify Product Setup for ELOWRA

## Product Catalog Setup

### 1. Create Products in Shopify Admin

#### CloudClean™ Gentle Cleanser
- **Title**: CloudClean™ Gentle Cleanser
- **Price**: $28.00
- **SKU**: ELOWRA-CC-001
- **Weight**: 120ml
- **Product Type**: Cleanser
- **Vendor**: ELOWRA
- **Tags**: sensitive-skin, step-1, cleanser, gentle
- **Description**: Gentle cleansing foam that removes impurities without stripping natural oils.

**Metafields**:
- `custom.step_number`: 1
- `custom.features`: ["Hypoallergenic formula", "pH balanced", "Fragrance-free"]
- `custom.skin_types`: ["Sensitive", "Dry", "All Types"]

#### VeilDew™ Hydrating Serum
- **Title**: VeilDew™ Hydrating Serum
- **Price**: $45.00
- **SKU**: ELOWRA-VD-001
- **Weight**: 30ml
- **Product Type**: Serum
- **Vendor**: ELOWRA
- **Tags**: sensitive-skin, step-2, serum, hydrating
- **Description**: Lightweight hydrating serum that locks in moisture for 24-hour comfort.

**Metafields**:
- `custom.step_number`: 2
- `custom.features`: ["Hyaluronic acid complex", "Non-comedogenic", "Fast absorbing"]
- `custom.skin_types`: ["Dry", "Dehydrated", "All Types"]

#### MoonSilk™ Night Moisturizer
- **Title**: MoonSilk™ Night Moisturizer
- **Price**: $52.00
- **SKU**: ELOWRA-MS-001
- **Weight**: 50ml
- **Product Type**: Moisturizer
- **Vendor**: ELOWRA
- **Tags**: sensitive-skin, step-3, moisturizer, night-care
- **Description**: Rich night moisturizer that repairs and rejuvenates while you sleep.

**Metafields**:
- `custom.step_number`: 3
- `custom.features`: ["Peptide complex", "Barrier repair", "Anti-inflammatory"]
- `custom.skin_types`: ["Mature", "Dry", "All Types"]

#### The Ritual Kit (Bundle)
- **Title**: The Ritual Kit - Complete 3-Step System
- **Price**: $89.00 (Compare at $125.00)
- **SKU**: ELOWRA-KIT-001
- **Product Type**: Kit
- **Vendor**: ELOWRA
- **Tags**: bundle, ritual-kit, complete-system, bestseller

**Variants**:
1. One-time Purchase: $89.00
2. Subscribe & Save: $75.65 (15% off)

**Metafields**:
- `custom.is_bundle`: true
- `custom.included_products`: ["CloudClean™", "VeilDew™", "MoonSilk™"]
- `custom.savings_amount`: "$36.00"
- `custom.duration`: "2-month supply"

### 2. Set Up Product Collections

#### Main Collections
1. **The Ritual Kit** (Featured collection)
2. **Individual Products**
3. **Sensitive Skin**
4. **New Arrivals**
5. **Best Sellers**

#### Collection Rules
- **Sensitive Skin**: Products tagged with "sensitive-skin"
- **Best Sellers**: Manual selection of top products
- **New Arrivals**: Products created in last 90 days

### 3. Configure Metafields

Go to Settings > Metafields > Products and create:

```json
{
  "namespace": "custom",
  "key": "step_number",
  "name": "Step Number",
  "type": "number_integer"
}
```

```json
{
  "namespace": "custom", 
  "key": "features",
  "name": "Product Features",
  "type": "list.single_line_text_field"
}
```

```json
{
  "namespace": "custom",
  "key": "skin_types", 
  "name": "Suitable Skin Types",
  "type": "list.single_line_text_field"
}
```

### 4. Subscription Setup

#### Option A: Shopify Subscriptions (Native)
1. Go to Apps > Shopify Subscriptions
2. Create subscription plan for each product
3. Set 15% discount for subscriptions
4. Configure delivery frequency (every 8 weeks)

#### Option B: Third-party Apps
- **ReCharge**: Most popular subscription app
- **Bold Subscriptions**: Feature-rich alternative
- **Seal Subscriptions**: Built for Shopify Plus

### 5. Inventory Management

#### Stock Levels
- CloudClean™: 500 units
- VeilDew™: 300 units  
- MoonSilk™: 400 units
- Ritual Kit: 200 units

#### Inventory Tracking
- Enable inventory tracking for all products
- Set low stock alerts at 20 units
- Configure "Continue selling when out of stock" as needed

### 6. SEO Optimization

#### Product SEO Titles
- CloudClean™: "CloudClean™ Gentle Cleanser - Sensitive Skin Face Wash | ELOWRA"
- VeilDew™: "VeilDew™ Hydrating Serum - 24-Hour Moisture Lock | ELOWRA"
- MoonSilk™: "MoonSilk™ Night Moisturizer - Overnight Skin Repair | ELOWRA"
- Ritual Kit: "The Ritual Kit - Complete 3-Step Skincare System | ELOWRA"

#### Meta Descriptions
Keep under 160 characters and include key benefits and skin types.

### 7. Image Guidelines

#### Product Images (minimum 2048x2048px)
1. **Main Image**: Product on white background
2. **Lifestyle**: Product in use or styled setting
3. **Ingredients**: Close-up of key ingredients
4. **Before/After**: Results imagery (if available)
5. **Bundle**: All products together for kit

#### Alt Text Format
"[Product Name] - [Key Benefit] for [Skin Type] by ELOWRA"

### 8. Pricing Strategy

#### Individual Products
- Premium positioning at $28-52 range
- Compare-at prices for promotional periods

#### Bundle Pricing
- Kit saves $36 vs individual purchases
- Subscription saves additional 15%
- Free shipping threshold at $75

### 9. Shipping Configuration

#### Shipping Zones
- United States: Free shipping over $75
- Canada: $10 flat rate, free over $100
- International: Calculated rates

#### Shipping Classes
- Standard products: Regular rates
- Bundles: Free shipping included